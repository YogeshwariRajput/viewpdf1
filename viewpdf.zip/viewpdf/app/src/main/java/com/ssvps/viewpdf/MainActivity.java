package com.ssvps.viewpdf;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {



        private static final int PICK_PDF_REQUEST = 1;
        private PdfRenderer pdfRenderer;
        private PdfRenderer.Page currentPage;
        private ParcelFileDescriptor parcelFileDescriptor;

        private ImageView pdfImageView;
        private Button previousButton, nextButton;

        private int currentPageIndex = 0;
        private int totalPages = 0;

        // Matrix for scaling and transformations
        private Matrix matrix;
        private ScaleGestureDetector scaleGestureDetector;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            pdfImageView = findViewById(R.id.pdf_image_view);
            previousButton = findViewById(R.id.previous_button);
            nextButton = findViewById(R.id.next_button);
            Button selectPdfButton = findViewById(R.id.select_pdf_button);

            selectPdfButton.setOnClickListener(v -> openPdfFilePicker());
            previousButton.setOnClickListener(v -> showPage(currentPageIndex - 1));
            nextButton.setOnClickListener(v -> showPage(currentPageIndex + 1));

            // Initialize the Matrix for zoom
            matrix = new Matrix();
            pdfImageView.setImageMatrix(matrix);

            // Initialize ScaleGestureDetector to handle pinch zoom gestures
            scaleGestureDetector = new ScaleGestureDetector(this, new ScaleListener());

            updateNavigationButtons();
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            // Pass touch events to the ScaleGestureDetector for pinch zoom
            scaleGestureDetector.onTouchEvent(event);
            return super.onTouchEvent(event);
        }

        private void openPdfFilePicker() {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("application/pdf");
            startActivityForResult(intent, PICK_PDF_REQUEST);
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null) {
                Uri pdfUri = data.getData();
                if (pdfUri != null) {
                    displayPdf(pdfUri);
                }
            }
        }

        private void displayPdf(Uri pdfUri) {
            try {
                parcelFileDescriptor = getContentResolver().openFileDescriptor(pdfUri, "r");
                if (parcelFileDescriptor != null) {
                    pdfRenderer = new PdfRenderer(parcelFileDescriptor);
                    totalPages = pdfRenderer.getPageCount();
                    showPage(0); // Display the first page initially
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private void showPage(int pageIndex) {
            if (pdfRenderer == null || pageIndex < 0 || pageIndex >= totalPages) {
                return;
            }

            // Close the current page if open
            if (currentPage != null) {
                currentPage.close();
            }

            // Open the new page
            currentPage = pdfRenderer.openPage(pageIndex);
            Bitmap bitmap = Bitmap.createBitmap(currentPage.getWidth(), currentPage.getHeight(), Bitmap.Config.ARGB_8888);
            currentPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            pdfImageView.setImageBitmap(bitmap);

            currentPageIndex = pageIndex;
            updateNavigationButtons();
        }

        private void updateNavigationButtons() {
            previousButton.setEnabled(currentPageIndex > 0);
            nextButton.setEnabled(currentPageIndex < totalPages - 1);
        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            if (currentPage != null) {
                currentPage.close();
            }
            if (pdfRenderer != null) {
                pdfRenderer.close();
            }
            if (parcelFileDescriptor != null) {
                try {
                    parcelFileDescriptor.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                // Get the scale factor
                float scaleFactor = detector.getScaleFactor();

                // If the scale factor is valid, apply it to the matrix
                if (scaleFactor > 0) {
                    matrix.postScale(scaleFactor, scaleFactor, detector.getFocusX(), detector.getFocusY());
                    pdfImageView.setImageMatrix(matrix);
                }
                return true;
            }
        }
    }
